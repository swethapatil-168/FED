const navbar = () => {
    return `        <div class="nav">
    <div><a href="./index.html"><img src="./logo2.png" alt="food app"></a></div>

    <ul>
       
        <li><a href="wallet.html">Wallet</a></li>
        <li><a href="like.html">Favorite</a></li>
        <li><a href="cart.html">Cart</a><sup></sup></li>
        <li><a href="login.html">Login</a></li>
        <li><a href="signup.html">SignUp</a></li>
    </ul>
</div>`

}

export default navbar;

